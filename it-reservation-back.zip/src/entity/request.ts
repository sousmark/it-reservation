export class LightRequest {
  ipn!: number;
  page!: number;
  object!: Object;
  date!: Date;
}