export class LightResponse {
  success!: number;
  message!: string;
  data!: Object;
  currentPage!: number;
  totalPage!: number;
}