import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-e-commerce',
  templateUrl: './calendar.component.html',
})
export class CalendarComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
