export class EventModel {
    title: string;
    description: string;
    creator: string;
    date: string;
    start: string;
    finish: string;
}