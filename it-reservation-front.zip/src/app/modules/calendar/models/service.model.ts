export class ServiceModel {
    id: number;
    name: string;
    title: string;
    description: string;
    id_employee: string;
}