import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error2',
  templateUrl: './error2.component.html',
})
export class Error2Component implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
