import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error6',
  templateUrl: './error6.component.html',
})
export class Error6Component implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
