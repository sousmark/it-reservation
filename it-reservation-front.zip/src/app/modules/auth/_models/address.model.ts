export class AddressModel {
  addressLine: string;
  city: string;
  state: string;
  postCode: string;
}
