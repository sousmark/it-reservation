import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-e-commerce',
  templateUrl: './e-commerce.component.html',
})
export class ECommerceComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
