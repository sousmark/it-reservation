import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-material',
  templateUrl: './material.component.html',
})
export class MaterialComponent {}
