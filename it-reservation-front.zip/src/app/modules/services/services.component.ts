import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-e-commerce',
  templateUrl: './services.component.html',
})
export class ServicesComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
