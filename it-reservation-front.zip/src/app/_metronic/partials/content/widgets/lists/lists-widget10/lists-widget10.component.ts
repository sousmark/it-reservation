import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-lists-widget10',
  templateUrl: './lists-widget10.component.html',
})
export class ListsWidget10Component {
  @Input() cssClass;
  constructor() { }
}
