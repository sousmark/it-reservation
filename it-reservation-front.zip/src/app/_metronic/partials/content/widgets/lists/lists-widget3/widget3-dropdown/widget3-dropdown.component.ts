import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-widget3-dropdown',
  templateUrl: './widget3-dropdown.component.html',
})
export class Widget3DropdownComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
