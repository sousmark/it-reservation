export class BreadcrumbItemModel {
  title: string;
  linkText: string;
  linkPath: string;
}
