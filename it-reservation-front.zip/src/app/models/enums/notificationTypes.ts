export enum NotificationTypes {
    SUCCESS,
    FAILURE,
    INFO,
    WARNING,
    STANDARD
}