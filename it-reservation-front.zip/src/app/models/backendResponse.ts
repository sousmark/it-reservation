export interface BackendResponse {
    success: boolean;
    data: any;
    message: string;
}
